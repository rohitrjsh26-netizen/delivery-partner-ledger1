# Delivery Partner Ledger — Android project

This project wraps the existing offline-first HTML tracker in a native Android APK using Android WebView. Minimum Android API is 23 (Android 6.0); actual compatibility still needs device testing.

## Build APK using GitHub Actions from a phone

1. Extract this ZIP on your phone if needed, or upload the ZIP's *contents* to a new GitHub repository. GitHub's web UI doesn't always upload folders easily; the GitHub mobile app is limited for repository file editing, so a browser in Desktop site mode may be easier.
2. Create a public or private repository named `delivery-partner-ledger`.
3. Upload all files and folders from this project into the repository root. Ensure `.github/workflows/build-apk.yml` is included. Do not upload the outer folder as a single nested folder unless you also adjust the project root.
4. Commit the files to branch `main`.
5. Open the repository's **Actions** tab. If prompted, enable Actions.
6. Choose **Build Delivery Partner Ledger APK** from the workflow list, tap **Run workflow**, choose `main`, and confirm. A push to `main` also triggers a build.
7. Open the running workflow, wait for the job to finish, and open its run page.
8. Under **Artifacts**, download `delivery-partner-ledger-debug-apk`. GitHub downloads it as a ZIP; extract `app-debug.apk`.
9. Tap the APK on your Android phone to install. If Android blocks it, allow installation from that browser/file manager in Android settings, then retry. Turn the permission off again if you prefer.

## Important
- This is a debug APK for personal testing, not a Play Store release. It is not release-signed.
- This APK uses local HTML and browser localStorage; data stays on this device/app WebView storage. Clearing app data or uninstalling may delete records. Export CSV backups.
- The workflow downloads Android SDK components and Gradle dependencies, so it needs network access. GitHub Actions usage limits may apply.
- Do not store passwords, tokens, or private signing keys in repository files.
- Verify the app on your phone before relying on it for financial records.
